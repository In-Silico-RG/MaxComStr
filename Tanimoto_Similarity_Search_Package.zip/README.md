# Tanimoto Similarity Search
This script searches KEGG, PubChem, and ChEBI for compounds similar to a given SMILES using Tanimoto similarity.
